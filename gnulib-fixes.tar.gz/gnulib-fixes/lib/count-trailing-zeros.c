#include <config.h>
#define COUNT_TRAILING_ZEROS_INLINE _GL_EXTERN_INLINE
#include "count-trailing-zeros.h"
