#define FUNC ffsl
#define TYPE long int
#define GCC_BUILTIN __builtin_ffsl
#include "ffsl.h"
